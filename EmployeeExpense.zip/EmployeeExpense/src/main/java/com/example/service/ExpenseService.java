package com.example.service;

import com.example.entity.Expense;
import java.util.List;


public class ExpenseService {
	List<Expense> getAllExpenses();
    Expense createExpense(Expense expense);
}
