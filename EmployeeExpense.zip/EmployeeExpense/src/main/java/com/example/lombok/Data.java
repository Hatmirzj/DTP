package com.example.lombok;

public class Data {

}
