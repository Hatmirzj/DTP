package com.example.entity;

import lombok.Data; 

import jakarta.persistence.*;

@Data
@Entity
@Table(name = "expenses")
public class Expense {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String description;

    private Double amount;

    @Column(nullable = false)
    private String employeeId;

    private String date;
}
