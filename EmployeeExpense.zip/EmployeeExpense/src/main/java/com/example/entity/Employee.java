package com.example.entity;

import lombok.Data;

import jakarta.persistence.*;

@Data
@Entity // Marks this class as a JPA entity
@Table(name = "employees") // Maps to a table named 'employees'
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generates the primary key
    private Long id;

    @Column(nullable = false) // Maps to a non-nullable column
    private String name;

    private String department;
    
    
}
