package com.example.EmployeeExpense;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeExpenseApplicationTests {

	@Test
	void contextLoads() {
	}

}
